# full-projects-starter


## structure

index.html -> html code
css/* -> styling
js/* -> javascript code
js/* -> javascript directory
